////////////////////////////////////////////////////////////////////////////
// ADOBE SYSTEMS INCORPORATED
// Copyright 2008 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the
// terms of the Adobe license agreement accompanying it.  If you have received this file from a
// source other than Adobe, then your use, modification, or distribution of it requires the prior
// written permission of Adobe.
/////////////////////////////////////////////////////////////////////////////

/** 
 @fileoverview Shows how to create a TabbedPalette that shows a Web page.
 @class Shows how to create a TabbedPalette that shows a Web page.
 
 <h4>Usage</h4>
  <ol>
 <li>Run the snippet in the ExtendScript Toolkit (see Readme.txt), with Adobe Bridge CS5 as the target.
 <li>You should see a new tabbed palette added to the default top-left position.
 <li>Try dragging the palette to the Content pane of Bridge; it should show the Adobe website.
 </ol>
    
  <h4>Description</h4>

   <p>Adds a script-defined tab to all Bridge browser windows.  
   
   <p>Creates a TabbedPalette object. The tab is of the "web" type, 
   and shows the Adobe home page. It could point to a HTML page 
   containing user-interface components; in this case,
   you would need to make sure that the HTML file exists in the expected
   location.

   <p>Adds the tab to existing Bridge browser windows, then defines
   an event handler to listen for the creation of a new browser window,
   and add the tab to it.

   <p>The new tab appears in the default upper-left palette in the browser.<br />

   @see SnpCreateTabbedPaletteScriptUI

   @constructor Constructor.
 */

function SnpCreateWebTabbedPalette() {
  /**
   The context in which this snippet can run.
   @type String
  */
  this.requiredContext =
    '\tExecute against Bridge main engine.\nBridge must not be running'
  $.level = 1 // Debugging level
  this.paletteRefs = null
}

/**
 Functional part of this snippet.  
 
 Creates the TabbedPalette object, pointing it to the Adobe home page.
 Adds the tab to all open Bridge browser windows.
 Defines and registers an event handler to listen for the creation of a
 new Bridge browser window, then  adds the tab to that window.
  @return True if the snippet ran as expected, false otherwise.  
  @type Boolean
*/
SnpCreateWebTabbedPalette.prototype.run = function() {
  var retval = true
  if (!this.canRun()) {
    retval = false
    return retval
  }
  this.paletteRefs = new Array()
  var wrapper = this
  // Create the palette of type "web"
  function addWebPalette(doc) {
    var webPalette = new TabbedPalette(
      doc,
      'SnpCreateWebTabbedPalette',
      'SnpWebPalette',
      'web',
      'http://www.adobe.com'
    )
    wrapper.paletteRefs.push(webPalette)
  }

  // Add the tabbed palette to all open Bridge windows
  for (var i = 0; i < app.documents.length; i++) {
    addWebPalette(app.documents[i])
  }

  // Create the event handler
  onNewBrowserEvent = function(event) {
    if (event.object instanceof Document) {
      // If a new Bridge window is opened then add the tabbed palette
      if (event.type == 'create') {
        addWebPalette(event.object)
      }
    }
    return { handled: false } // Continue to do other handlers
  }

  // Add the event handler to the application
  app.eventHandlers.push({ handler: onNewBrowserEvent })

  return retval
}

/**
  Determines whether snippet can be run given current context.  The snippet 
  fails if these preconditions are not met:
  <ul>
  <li> Must be running in Bridge
  </ul>
 
  @return True is this snippet can run, false otherwise
  @type boolean
*/
SnpCreateWebTabbedPalette.prototype.canRun = function() {
  // Need to be running in Bridge
  if (BridgeTalk.appName == 'bridge') {
    return true
  }

  // Fail if these preconditions are not met.
  // Bridge must be running,
  $.writeln('ERROR:: Cannot run SnpCreateWebTabbedPalette')
  $.writeln(this.requiredContext)
  return false
}

/**
 "main program": construct an anonymous instance and run it
  as long as we are not unit-testing this snippet.
*/
if (typeof SnpCreateWebTabbedPalette_unitTest == 'undefined') {
  new SnpCreateWebTabbedPalette().run()
}
// vi: ft=javascript
