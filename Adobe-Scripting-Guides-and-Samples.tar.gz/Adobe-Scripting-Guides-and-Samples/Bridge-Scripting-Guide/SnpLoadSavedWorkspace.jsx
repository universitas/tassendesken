////////////////////////////////////////////////////////////////////////////
// ADOBE SYSTEMS INCORPORATED
// Copyright 2008 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the
// terms of the Adobe license agreement accompanying it.  If you have received this file from a
// source other than Adobe, then your use, modification, or distribution of it requires the prior
// written permission of Adobe.
/////////////////////////////////////////////////////////////////////////////

/** 
 @fileoverview Shows how to load a previously saved workspace, which you have copied to
 the appropriate location for saved workspaces.

  @class Shows how to load a previously saved workspace, which you have copied to the appropriate location for saved workspaces.
 
   <h4> Usage</h4>
   <ol>
  <li> Copy the workspace file SDKINSTALL/sdksamples/javascript/resources/BridgeSDKCustomWSpace.workspace 
  to the default location for saved workspaces:
<pre>
      In Windows: - C:\Program Files\Common Files\Adobe\Bridge CS5 Extensions\Workspaces
      In Mac OS: /Library/Application Support/Adobe/Bridge CS5 Extensions/Workspaces/
</pre>
  <li>Run the snippet in the ExtendScript Toolkit (see Readme.txt).
  <li>Loads the previously saved workspace into Adobe Bridge, which uses a
  a tabbed palette to show a Flash movie in the center of the browser window.  
  </ol>

  <h4>Description</h4>
  Loads a previously saved workspace into Adobe Bridge.  The saved workspace in this snippet uses
  a tabbed palette to show a Flash movie in the center of the browser window.  For this snippet to run, 
  you must copy the workspace file to the workspaces folder as described above.
   <p>
  This sample recreates the palette that contains the Flash Player,using the same ID that
  was used to create it originally, and loads the movie that is shown in 
  that component. It then loads the workspace by calling Document.setWorkspace(), 
  passing in ID with which the workspace was saved.  
   <p>
  To save a workspace with your own custom palette:
  <ul>
  <li> Create the TabbedPalette and show it in Adobe Bridge.
  <li> Manually arrange the workspace by placing the palettes in the desired positions.
  <li> Save the workspace by choosing Window > Workspace > Save Workspace.
  </ul>
   <p>
  To load the saved workspace:
  <ul>
  <li> Create a TabbedPalette with the same ID as originally used
  <li> Load the workspace using Document.setWorkspace(workspaceID), with the same ID used to save it.
  </ul>
     
  @constructor Constructor
 */
function SnpLoadSavedWorkspace() {
  /**
   The context in which this snippet can run.
   @type String
  */
  this.requiredContext = '\tNeed to be running in context of Bridge\n'

  /**
   The ID of the workspace to load
   @type String
  */
  this.workspaceID = 'BridgeSDKCustomWSpace'

  // Tells us where this script is running from
  var scriptsFile = new File($.fileName)

  /**
   The Flash movie to load into Bridge
   @type File
  */
  this.flashFile = new File(
    scriptsFile.parent.fsName + '/resources/SnpCreateFlashControl.swf'
  )
}

/**
 Functional part of this snippet.  Creates the TabbedPalette that will be used 
 by the saved workspace and then loads the workspace.
 @return True if the snippet ran as expected, false otherwise
 @type Boolean
*/
SnpLoadSavedWorkspace.prototype.run = function() {
  if (!this.canRun()) {
    return false
  }

  $.writeln('About to run SnpLoadSavedWorkspace')

  // Use the same ID that was used to create the TabbedPalette
  // when the workspace was saved
  flashPalette = new TabbedPalette(
    app.document,
    'From SnpLoadSavedWorkspace',
    'SnpLoadSavedWorkspacePalette',
    'script'
  )

  // Add the elements to the palette
  var cBounds = flashPalette.content.bounds
  var flashPlayer = flashPalette.content.add('flashplayer', cBounds)

  // Force the layout manager to recalculate container sizes
  flashPalette.content.layout.layout(true)

  // Load and play the Flash movie.
  flashPlayer.loadMovie(this.flashFile)

  flashPalette.content.layout.layout(true)

  // Resize the Flash Player when the palette is resized.
  flashPalette.content.onResize = function() {
    flashPlayer.bounds = flashPalette.content.bounds
    flashPalette.content.layout.layout(true)
  }

  // Load the workspace
  app.document.setWorkspace(this.workspaceID)

  $.writeln('Ran SnpLoadSavedWorkspace')

  return true
}

/**
 Determines whether snippet can be run given current context.  The snippet 
 fails if these preconditions are not met: 
 <ul>
 <li> Must run in Bridge
 <li> The SWF file must exist in the file system.
 </ul>
 @return True is this snippet can run, false otherwise
 @type Boolean
*/
SnpLoadSavedWorkspace.prototype.canRun = function() {
  if (BridgeTalk.appName == 'bridge' && this.flashFile.exists) {
    return true
  }
  $.writeln('ERROR:: Cannot run SnpLoadSavedWorkspace')
  $.writeln(this.requiredContext)
  return false
}

/**
 "main program": construct an anonymous instance and run it
  as long as we are not unit-testing this snippet.
*/
if (typeof SnpLoadSavedWorkspace_unitTest == 'undefined') {
  new SnpLoadSavedWorkspace().run()
}
// vi: ft=javascript
