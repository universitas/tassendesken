////////////////////////////////////////////////////////////////////////////
// ADOBE SYSTEMS INCORPORATED
// Copyright 2008 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the
// terms of the Adobe license agreement accompanying it.  If you have received this file from a
// source other than Adobe, then your use, modification, or distribution of it requires the prior
// written permission of Adobe.
/////////////////////////////////////////////////////////////////////////////

/** 
 @fileoverview Shows how to load and run a Flash movie in Bridge using the ScriptUI FlashPlayer.
  @class Shows how to load and run a Flash movie in Bridge using the ScriptUI FlashPlayer.
 
  <h4>Usage</h4>
	
  <ol>
  <li>Run the snippet in the ExtendScript Toolkit (see Readme.txt), with Bridge CS5 as the target.
  <li>You should see a new tabbed palette in the Bridge browser window, showing a Flash movie.
  </ol>
 
 <h4>Description</h4>
 
 <p>Adds a script-defined tabbed palette to the Bridge browser window that plays a Flash movie.

 <p>The tabbed palette is of the "script" type, and contains ScriptUI components, including
 control buttons and a FlashPlayer element. The new palette appears in the default upper-left corner of Bridge.<br />

 <p>Loads the Flash movie, an SWF file, into the FlashPlayer component using control's loadMovie() function.
 The 'file' parameter must be a valid ExtendScript File object that references any type of Flash file. 
 
 <p>See the JavaScript Tools Guide for details of Flash Player controls.<br />

 @see FlashDemo
 
  @constructor Constructor
*/
function SnpCreateFlashControl() {

	/**
	 The context in which this snippet can run.
	 @type String
	*/
	this.requiredContext = "\tNeed to be running in context of Bridge\nand the Flash file must be available.";	

	// Tells us where this script is running from
	var scriptsFile = new File($.fileName);

	/**
	 The Flash movie to load into Bridge
	 @type File
	*/
	this.flashFile = new File(scriptsFile.parent.fsName + "/resources/SnpCreateFlashControl.swf");
	
	this.paletteRef = null;
}

/**
 Functional part of this snippet.  
 
 Creates a TabbedPalette and adds the ScriptUI components to it. 
 Creates event handlers for the buttons that control the playback,
 and handles resizing of the palette and the FlashPlayer component.
	@return True if the snippet ran as expected, false otherwise
 	@type Boolean
*/
SnpCreateFlashControl.prototype.run = function() 
{
	if(!this.canRun()) 
	{
		return false;
	}
	
	$.writeln("About to run SnpCreateFlashControl");
	
	// Create a tabbed palette
	flashPalette = new TabbedPalette(app.document, "SDK SnpCreateFlashControl - Flash Player", "snpCFP", "script");
	this.paletteRef = flashPalette;
	
	// Set the orientation for the content of the TabbedPalette
	flashPalette.content.orientation = "column";
	
	// add the elements to the palette
	var pnl = flashPalette.content.add("group");

	var flashPlayer = pnl.add("flashplayer", pnl.bounds);
	flashPlayer.preferredSize = [300, 300];
	
	var btnGroup = flashPalette.content.add("group");
	
	// Load and play the Flash movie. 
	flashPlayer.loadMovie(this.flashFile);
	
	// Resize components if the tabbed palette is moved
	function resizeElements()
	{
		var cBounds = flashPalette.content.bounds;
		pnl.bounds = [cBounds.left, cBounds.top, cBounds.right, cBounds.bottom-65];
		flashPlayer.bounds = pnl.bounds;
	}
		

	// Size element to the initial size of the palette.
	resizeElements();
	flashPalette.content.layout.layout(true);
	
	// Handler that resizes contents if the palette is moved or resizeded
	flashPalette.content.onResize = function()
	{
		resizeElements();
		flashPalette.content.layout.layout(true);

	}
	
	$.writeln("Ran SnpCreateFlashControl");
	
	return true;
}


/**
 Determines whether snippet can be run given current context. The snippet  
 fails if these preconditions are not met: 
 <ul>
 <li> Must run in Bridge
 <li> The SWF file must exist in the file system.
 </ul>
 	@return True is this snippet can run, false otherwise
 	@type Boolean
*/
SnpCreateFlashControl.prototype.canRun = function() 
{
	if(BridgeTalk.appName == "bridge" && this.flashFile.exists) 
	{ 
		return true;
	}
	$.writeln("ERROR:: Cannot run SnpCreateFlashControl");
	$.writeln(this.requiredContext);
	return false;
}

/**
 "main program": construct an anonymous instance and run it
  as long as we are not unit-testing this snippet.
*/
if(typeof(SnpCreateFlashControl_unitTest) == "undefined") {
    new SnpCreateFlashControl().run();
}
