////////////////////////////////////////////////////////////////////////////
// ADOBE SYSTEMS INCORPORATED
// Copyright 2008 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the
// terms of the Adobe license agreement accompanying it.  If you have received this file from a
// source other than Adobe, then your use, modification, or distribution of it requires the prior
// written permission of Adobe.
/////////////////////////////////////////////////////////////////////////////

/** 
  @fileoverview Shows how to communicate with a ScriptUI FlashPlayer in Adobe Bridge using ActionScript
  @class Shows how to communicate with a ScriptUI FlashPlayer in Adobe Bridge using ActionScript
 
  <h4>Usage</h4>
  
  <ol>
  <li> Read the section on <a href="#flashSec">Flash Player Security</a> below.
  <li> Run the sample in the ExtendScript Toolkit (see Readme.txt), with Bridge CS5 as the target.
   <li>The Flash-movie palette appears in the default top left corner of Bridge.
  <li> On the first page of the Flash movie, click buttons to receive data from Bridge, 
  which is displayed in the Flash Player.
  <li> Click Next Page to show the second page. Click buttons to call JavaScript functions from the ActionScript environment
         and pass data as arguments to the functions.
  <li> Click Next Page to show the third page. In the Bridge menu bar, choose items from the 'SDK FlashDemo' menu to invoke 
       ActionScript functions that pass various data values to the Flash application, to be displayed in the Flash Player.
  <li> Click Next Page to show the fourth page. Select a thumbnail in Bridge to send data about the Thumbnail state to the Flash 
   	application, which displays it in the Flash Player.
  <li> Use the moving arrows to navigate between slides in the Flash Player.
  </ol>
   
  <h4>Description</h4>

<p>This sample shows how to use the ScriptUI FlashPlayer element to invoke JavaScript 
  functions in ActionScript, and ActionsScript functions in JavaScript. It passes simple
  data between the two scripting environments, and displays passed values.
 
 <ul>
  <li> Menu items invoke ActionScript functions that send data from the Flash environment,
  	and display the received data in Bridge
  <li> A Thumbnail event handler sends information about the selected Bridge Thumbnail
       to ActionScript functions, which display the data in the Flash Player.
  </ul>

<p>The Flash application to be used with this sample must be located in the resources 
  folder and have the same name as this sample. The application is a Flash presentation 
  that has 4 slides.  Each slide has a layer named 'Actions' which contains an 
  ActionScript script. The ActionScript scripts show how to import the ExternalInterface class, 
  and how to register and call external functions, which are defined in this script.
  The ActionScript source code is provided as a comment block in the
  FlashDemo.JSX file. The compiled code for the scripts is in .\resources\FlashDemo.fla
  
<a name="flashSec"><h4>Flash Player Security</h4></a>

   Adobe Bridge supports the Flash Player client-runtime security model. This affects which SWF files 
   can be loaded into Bridge and run successfully. You must set the correct security permission
   to allow the operation that the SWF file performs.
   
   There are 3 basic levels of security for local SWF files:  
   <ul>
	<li> Access the local file system only (default):  
	A local SWF file can read from the local file system and 
  	universal naming convention (UNC) network paths, but cannot communicate with the Internet.   
  
	<li> Access the network only:  
	A local SWF file can access the network, but not the local file system where it is installed.
  
	<li> Access to the local file system and the network: 
	A local SWF file can read from the local file system  where it is installed,
 	read and write to and from servers, and can cross-script other SWF files on
  	either the network or the local file system. These files are trusted.
  </ul>
   
   To create a SWF file that can 'access the local file system only' or 'access the network only',
   edit the FLA file and do the following:

  <li> In Adobe Flash, select File > Publish Settings
  <li> In the dialog, select the Flash tab
  <li> Set the option for 'Local playback security' to either  'access network only' or 'access local files only'
<p>  
  For more information on local file security  see:
<p>
<a href="http://livedocs.adobe.com/flex/3/html/05B_Security_03.html">http://livedocs.adobe.com/flex/3/html/05B_Security_03.html</a><br />

<p>To allow a local file to be trusted,(that is, allow a SWF file to access both network and local files 
  as well as allow cross scripting), you can either create a trust file, or use the Settings Manager. 
  This sample and the accompanying SWF file have been created with the default permissions; therefore 
  to run the sample correctly, you must use one of these techniques, as described in the following sections.
  
  <h4>Create a Trust File </h4>
  
  You can create a trust file in either the Global Flash Player Trust directory or in the User Flash Player Trust directory.  
  A Trust file is a simple text file with a .cfg file extension, that contains the location to a local SWF file. 
  For example, to run this sample as a trusted file on Windows, create a text file that contains the path and file name
  (replacing SDKINSTALL with your local SDK installation location):
  
<pre>	SDKINSTALL\sdksamples\javascript\resources\FlashDemo.swf</pre>
  
<p>Save this text file with the extension .cfg in a folder named 'FlashPlayerTrust' (which you may need to
create), in one of the following locations, depending on the platform and users for which the SWF should be trusted. 
  
<p>Global Flash Player Trust Directory
<ul>
	<li>In Windows: system\Macromed\Flash\FlashPlayerTrust
	<ul>
		<li>for example:<pre>C:\windows\system32\Macromed\Flash\FlashPlayerTrust</pre>
	</ul>
	<li>In Mac OS: app support/Macromedia/FlashPlayerTrust
	<ul>
		<li>for example:<pre>/Library/Application Support/Macromedia/FlashPlayerTrust</pre>
	</ul>
</ul>

<p>User Flash Player Trust Directory
<ul>
	<li>In Windows: app data\Macromedia\Flash Player\#Security\FlashPlayerTrust
	<ul>
		<li>for example:<pre>C:\Documents and Settings\your-user-name\Application Data\Macromedia\Flash Player\#Security\FlashPlayerTrust</pre> 
	</ul>
	<li>In Mac OS: app data/Macromedia/Flash Player/#Security/FlashPlayerTrust
	<ul>
		<li>for example:<pre>/Users/your-user-name/Library/Preferences/Macromedia/Flash Player/#Security/FlashPlayerTrust</pre>
	</ul>
	</li>
</ul> 

  <h4>Use the Settings Manager </h4>

   The Settings Manager allows you to make changes to various global settings, including whether to allow a SWF file
   to be trusted.  When Bridge loads a non-trusted file that attempts a trusted action, the Flash 
   Player presents a dialog giving the user the choice to navigate to the Settings Manager. 
<ul>
  <li>  When you run this sample (if you have not created a trust file for it) Bridge displays a security dialog
   warning about the SWF file. Click 'Settings...' in this dialog. <br> 
   The Adobe Flash Player Settings Manager opens in a web browser. 
   (You may need to install the Adobe Flash Plugin before you see this page correctly.)
  
  <li> On the Global Security Settings tab (the default tab), click 'Edit Locations' and choose 'Add Location' from
  	the drop down list. <br> A dialog appears showing the path of the SWF that Bridge is trying to load.

  <li> Click 'Browse for files', navigate to the location of the SWF file (SDKINSTALL/javascript/resources/FlashDemo.swf)
  	and click OK (There is no confirm dialog).

  <li> Close the web browser and restart Bridge.
 </ul>

   Bridge can now play the Flash movie and data can be passed between the two scripting environments.

  <p>For more  information on the Settings Manager and Trust files see:
  
  <p>
   <a href="http://livedocs.adobe.com/flex/3/html/05B_Security_03.html">http://livedocs.adobe.com/flex/3/html/05B_Security_03.html</a><br />

	@see SnpCreateFlashControl

  @constructor Constructor.
 */
function FlashDemo()
{

	// Tells us where this script is running from
	var scriptsFile = new File($.fileName);

	/**
	 The Flash movie to load into Bridge
	 @type File
	*/
	this.flashFile = new File(scriptsFile.parent.fsName + "/resources/FlashDemo.swf");

	/**
	 The context in which this snippet can run.
	 @type String
	*/
	this.requiredContext = "\tNeed to be running in context of Bridge\n";

}

/**
 Functional part of this Snippet.

 Creates a TabbedPalette of type "script", and adds a FlashPlayer control, 
 along with other text controls and buttons. Loads a Flash movie into the player, 
 whose scripts define ActionScript functions that can be called from the 
 player control. The movie starts playing automatically.

 Adds a new menu to Bridge, with menu items that invoke the various
 ActionScript functions. The functions pass data from the Flash scripting
 environment to the Bridge scripting environment.

 Defines an event handler for Bridge Thumbnails that sends data about the
 Thumbnail state to the Flash scripting environment.

 @return True if the snippet ran as expected, false otherwise
 @type Boolean
*/
FlashDemo.prototype.run = function() 
{
	if(!this.canRun())
	{
		return false;
	}

	// Create a tabbed palette
	var flashPalette = new TabbedPalette(app.document, "SDK FlashDemo: Flash Palette", "sdkTPFlashDemo", "script");

	// Set the player bounds to match the palette
	var cBounds = flashPalette.content.bounds;
	// add the Flash Player control to the palette.
	var flashPlayer = flashPalette.content.add("flashplayer", cBounds);	
	//var flashPlayer = flashPalette.content.add("flashplayer");
	flashPlayer.preferredSize = [300, 300];
	
	// Force the layout manager to recalculate the layout
	flashPalette.content.layout.layout(true);

	// Load the Flash file
	flashPlayer.loadMovie(this.flashFile);
	
	// Resize the Flash Player when the palette is resized.
	flashPalette.content.onResize = function()
	{
		flashPlayer.bounds = flashPalette.content.bounds;
		flashPalette.content.layout.layout(true);
	}

	
	flashPlayer.passArray = function(a)
	{
		alert(a);	
	}

	flashPlayer.passNumber = function(n)
	{
		alert(n);	
	}

	flashPlayer.passString = function(s)
	{
		alert(s);	
	}

	flashPlayer.passObject = function(o)
	{
		alert(o.toSource());
		return o;
	}
	
    // Called from ActionScript to return an array.
    flashPlayer.getJavaScriptArray = function()
    {
	    return new Array("Item 1", "Item 2");
    }
    
    // Called from ActionScript to return a number.
    flashPlayer.getJavaScriptNumber = function()
    {
	    return 12345;
    }

     // Called from ActionScript to return a string.
    flashPlayer.getJavaScriptString = function()
    {
	    return "From Bridge JavaScript (ES)";
    }

    // Called from ActionScript to return an object
    flashPlayer.getJavaScriptObject = function()
    {
	    var obj = {};
	    obj.prop1 = "JS Custom Object";
	    obj.prop2 = new Array("A", "B", "C");
	    obj.prop3 = 123;

	    return obj;
    }
    
	// Add the menu items
	var menu = new MenuElement("menu", "SDK FlashDemo", "after Help", "FlashDemoMenu");
	var m1 = new MenuElement("command", "SDK FlashDemo: Get Action Script Array", "at the end of FlashDemoMenu", "FlashDemoArrayMenu");
	var m2 = new MenuElement("command", "SDK FlashDemo: Get Action Script Number", "at the end of FlashDemoMenu", "FlashDemoNumberMenu");
	var m3 = new MenuElement("command", "SDK FlashDemo: Get Action Script String", "at the end of FlashDemoMenu", "FlashDemoStringMenu");
	var m4 =  new MenuElement("command", "SDK FlashDemo: Get Action Script Object", "at the end of FlashDemoMenu", "FlashDemoObjectMenu");

	// Add the menu event handlers
	// Each menu item invokes an ActionScript function that returns a value of a 
	// specific data type, then displays the value in an alert box.

	m1.onSelect = function(m)
	{
		result = flashPlayer.invokePlayerFunction("getActionScriptArray");
		$.writeln("FlashDemo: " + result);
	}

	m2.onSelect = function(m)
	{
		result = flashPlayer.invokePlayerFunction("getActionScriptNumber");
		$.writeln("FlashDemo: " + result);
	}

	m3.onSelect = function(m)
	{
		result = flashPlayer.invokePlayerFunction("getActionScriptString");
		$.writeln("FlashDemo: " + result);
	}
	
	m4.onSelect = function(m)
	{
		result = flashPlayer.invokePlayerFunction("getActionScriptObject");
		$.writeln("FlashDemo:\r\n" +result.prop1 + "\r\n" + result.prop2 + "\r\n" + result.prop3);
	}

	// Create the event handler for thumbnail selection
	// The handler passes thumbnail state information to ActionScript functions, which
	// display that information in the Flash Player
	onThumbSelect = function(event)
	{
		if(event.object instanceof Document)
		{
			if(event.type == "selectionsChanged")
			{
				var thumb = app.document.selections[0];
				if(thumb instanceof Thumbnail)
				{
					flashPlayer.invokePlayerFunction("populateFilename", thumb.name);
					flashPlayer.invokePlayerFunction("populateDateCreated", thumb.creationDate.toLocaleString());
					flashPlayer.invokePlayerFunction("populateDateModified", thumb.lastModifiedDate.toLocaleString());
					flashPlayer.invokePlayerFunction("populateMime", thumb.mimeType);
				}
			}
		}
		// continue will all other handlers
		return {handled: false};
	}

	// Add the Thumbnail event handler.
	app.eventHandlers.push({handler: onThumbSelect});

	return true;
}


/**
 Determines whether snippet can be run given current context.  The snippet 
 fails if these preconditions are not met:
 <ul>
 <li> Bridge must be running
 <li> The Flash file must be available
 </ul>
 @return True if this snippet can run, false  otherwise
 @type Boolean
*/
FlashDemo.prototype.canRun = function() {

	if(BridgeTalk.appName == "bridge" && this.flashFile.exists) 
	{ 
		return true;
	}
	$.writeln("ERROR:: Cannot run FlashDemo");
	$.writeln(this.requiredContext);
	return false;
}

/**
 "main program": construct an anonymous instance and run it
*/
if(typeof(FlashDemo_unitTest) == "undefined") {
	new FlashDemo().run();
}

// ////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////
// //  ActionScript sample code.
// //  Found in ./resources/FlashDemo.fla
// //  The Flash file has 3 slides, each with a layer names 'Actions' where the ActionScript is
// //  located.
// //
// // Slide 1
// //
// // Needed to allow for communication between ActionScript and JavaScript
// import flash.external.ExternalInterface;

// /**
//  All of the following functions call JavaScript defined methods
//  and will receive a particular data type
// */

// /**
//  Called when the 'Get Array' button is pressed.
// */
// getArray_btn.onRelease = function()
// {
// 	var res = ExternalInterface.call("getJavaScriptArray");
// 	arrayText.text = res;
// }

// /**
//  Called when the 'Get Number' button is pressed.
// */
// getNumbers_btn.onRelease = function()
// {
// 	var res = ExternalInterface.call("getJavaScriptNumber");
// 	numbersText.text = res;
// }

// /**
//  Called when the 'Get String' button is pressed.
// */
// getString_btn.onRelease = function()
// {
// 	var res = ExternalInterface.call("getJavaScriptString");
// 	stringText.text = res;
// }

// /**
//  Called when the 'Get Object' button is pressed.
// */
// getObject_btn.onRelease = function()
// {
// 	var res = ExternalInterface.call("getJavaScriptObject");
// 	objectText.text = "{" + res.prop1 + "}, {";
// 	objectText.text += res.prop2 + "},\n";
// 	objectText.text += "{" + res.prop3 + "}";
// }

// ////////////////////////////////////////////////////////////////////////////
// //	Slide 2
// //
// // Needed to allow for communication between ActionScript and JavaScript
// import flash.external.ExternalInterface;

// /**
//  All of the following functions call JavaScript defined methods
//  which are properties of the Flashplayer element.  These functions 
//  demonstrate passing arguments to the JavaScript functions.
// */

// /**
//  Called when the 'Send Array' button is pressed.
// */
// passArray_btn.onRelease = function()
// {
// 	var arr = new Array("val1", "val2");
// 	ExternalInterface.call("passArray", arr);
// 	
// 	pArrayText.text = arr.toString();
// }

// /**
//  Called when the 'Send Number' button is pressed.
// */
// passNumber_btn.onRelease = function()
// {
// 	var num = 12345;
// 	ExternalInterface.call("passNumber", num);
// 	
// 	pNumberText.text = num;
// }

// /**
//  Called when the 'Send String' button is pressed.
// */
// passString_btn.onRelease = function()
// {
// 	var str = "HelloBridge";
// 	ExternalInterface.call("passString", str);
// 	
// 	pStringText.text = str;
// }

// /**
//  Called when the 'Send Object' button is pressed.
// */
// passObject_btn.onRelease = function()
// {
// 	var obj = {};
// 	obj.prop1 = "MyString";
// 	obj.prop2 = ["val1", "val2"];
// 	obj.prop3 = 98765;
// 	
// 	var res = ExternalInterface.call("passObject", obj);	
// 	
// 	pObjectText.text = "{" + obj.prop1 + "}, ";
// 	pObjectText.text += "{" + obj.prop2 + "},\n";
// 	pObjectText.text += "{" + obj.prop3 + "}";
// }

// //////////////////////////////////////////////////////////////////////////////
// //		Slide 3
// //

// // Needed to allow for communication between ActionScript and JavaScript
// import flash.external.ExternalInterface;

// /**
//  Callback functions for JavaScript.  Registering the callback functions with
//  the ExternalInterface allows JavaScript to call into ActionScript for these functions
// */
// ExternalInterface.addCallback("getActionScriptArray", this, getActionScriptArray);
// ExternalInterface.addCallback("getActionScriptNumber", this, getActionScriptNumber);
// ExternalInterface.addCallback("getActionScriptString", this, getActionScriptString);
// ExternalInterface.addCallback("getActionScriptObject", this, getActionScriptObject);

// /**
//  All of these functions are called from JavaScript when certain menu items
//  are selected from the Bridge UI
// */

// /**
//  Called when the 'Flash Example > Get ActionScript Array' menu item is selected
//  */
// function getActionScriptArray()
// {
// 	var arr = new Array("Item 1", "Item 2", "Item 3");
// 	arrayText.text = arr.toString();
// 	return arr;
// }

// /**
//  Called when the 'Flash Example > Get ActionScript Number' menu item is selected
//  */
// function getActionScriptNumber()
// {
// 	numbersText.text = 98765;
// 	return 98765;
// }

// /**
//  Called when the 'Flash Example > Get ActionScript String' menu item is selected
//  */
// function getActionScriptString()
// {
// 	var aStr = "A String from ActionScript";
// 	stringText.text = aStr;
// 	return aStr;
// }

// /**
//  Called when the 'Flash Example > Get ActionScript Object' menu item is selected
//  */
// function getActionScriptObject()
// {
// 	var obj = {};
// 	obj.prop1 = "AS Custom Object";
// 	obj.prop2 = new Array("X", "Y", "Z");
// 	obj.prop3 = 987;
// 	
// 	objectText.text = "{" + obj.prop1 + "}, ";
// 	objectText.text += "{" + obj.prop2 + "},\n";
// 	objectText.text += "{" + obj.prop3 + "}";
// 	
// 	return obj;
// }

// //////////////////////////////////////////////////////////////////////////////
// //		Slide 4
// //
// //
// // Needed to allow for communication between ActionScript and JavaScript
// import flash.external.ExternalInterface;

// /**
//  Callback functions for JavaScript.  Registering the callback functions with
//  the ExternalInterface allows JavaScript to call into ActionScript for these functions
// */
// ExternalInterface.addCallback("populateFilename", this, populateFilename);
// ExternalInterface.addCallback("populateFilesize", this, populateFilesize);
// ExternalInterface.addCallback("populateDateCreated", this, populateDateCreated);
// ExternalInterface.addCallback("populateDateModified", this, populateDateModified);
// ExternalInterface.addCallback("populateMime", this, populateMime);

// /**
//  The following functions populate the Flash elements with information about
//  the currently selected thumbnail in Bridge.  When the selected thumbnail in Bridge 
//  is changed and event handler (defined in the jsx script file accompanying this sample)
//  will call these methods.
// */

// /**
//  Displays the file name
// */
// function populateFilename(fName)
// {
// 	fileName_txt.text = fName;
// }

// /**
//  Displays the file size
// */
// function populateFilesize(size)
// {
// 	fileSize_txt.text = size;
// }

// /**
//  Displays the date of creation
// */
// function populateDateCreated(date)
// {
// 	dateCreated_txt.text = date;
// }

// /**
//  Displays the last modified date
// */
// function populateDateModified(date)
// {
// 	dateMod_txt.text = date;
// }

// /**
//  Displays the mime type of the file
// */
// function populateMime(m)
// {
// 	mime_txt.text = m;
// }
// ////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////